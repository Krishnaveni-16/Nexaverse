package com.example.Nexaverseproject;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import com.example.Nexaverseproject.dao.RoleRepository;
import com.example.Nexaverseproject.dao.UserRepository;
import com.example.Nexaverseproject.model.Role;
import com.example.Nexaverseproject.model.User;

@Component
public class DataInitializer implements CommandLineRunner {

    @Autowired
    private RoleRepository roleRepo;

    @Autowired
    private UserRepository userRepo;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) throws Exception {

        // Ensure roles exist
        Role userRole = roleRepo.findByName("ROLE_USER")
                .orElseGet(() -> {
                    Role r = new Role();
                    r.setName("ROLE_USER");
                    return roleRepo.save(r);
                });

        Role adminRole = roleRepo.findByName("ROLE_ADMIN")
                .orElseGet(() -> {
                    Role r = new Role();
                    r.setName("ROLE_ADMIN");
                    return roleRepo.save(r);
                });

        // Create admin user if not exists
        String adminUsername = "admin";
        String adminPlainPassword = "Admin@123"; // change if you want

        Optional<User> existing = userRepo.findByUsername(adminUsername);
        if (existing.isEmpty()) {
            User admin = new User();
            admin.setUsername(adminUsername);
            admin.setPassword(passwordEncoder.encode(adminPlainPassword));
            admin.setEnabled(true);

            Set<Role> roles = new HashSet<>();
            roles.add(userRole);   // admin also has ROLE_USER
            roles.add(adminRole);  // and ROLE_ADMIN
            admin.setRoles(roles);

            userRepo.save(admin);
            System.out.println("Created admin user: " + adminUsername + " / " + adminPlainPassword);
        } else {
            System.out.println("Admin user already exists: " + adminUsername);
        }
    }
}
