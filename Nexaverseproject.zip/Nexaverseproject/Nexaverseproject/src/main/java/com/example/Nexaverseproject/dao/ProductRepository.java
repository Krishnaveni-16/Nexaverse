package com.example.Nexaverseproject.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.*;
import com.example.Nexaverseproject.model.*;
public interface ProductRepository extends JpaRepository<Product, Long> {
    List<Product> findByCategory(Category category);
}