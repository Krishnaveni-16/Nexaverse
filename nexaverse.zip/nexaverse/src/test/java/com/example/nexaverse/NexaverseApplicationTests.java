package com.example.nexaverse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NexaverseApplicationTests {

	@Test
	void contextLoads() {
	}

}
