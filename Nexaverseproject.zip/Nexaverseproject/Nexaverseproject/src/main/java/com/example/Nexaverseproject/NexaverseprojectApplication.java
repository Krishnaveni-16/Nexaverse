package com.example.Nexaverseproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NexaverseprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(NexaverseprojectApplication.class, args);
	}

}
