package com.example.nexaverse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NexaverseApplication {

	public static void main(String[] args) {
		SpringApplication.run(NexaverseApplication.class, args);
	}

}
