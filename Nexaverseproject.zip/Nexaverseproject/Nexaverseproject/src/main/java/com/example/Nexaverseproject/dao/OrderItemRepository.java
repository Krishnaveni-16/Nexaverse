package com.example.Nexaverseproject.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.Nexaverseproject.model.*;
public interface OrderItemRepository extends JpaRepository<OrderItem, Long> { }
