package com.example.demowithmany;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemowithmanyApplicationTests {

	@Test
	void contextLoads() {
	}

}
