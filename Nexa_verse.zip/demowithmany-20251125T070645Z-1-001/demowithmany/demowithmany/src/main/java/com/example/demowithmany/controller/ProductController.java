package com.example.demowithmany.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.*;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

//import com.example.demowithmany.model.*;
import com.example.demowithmany.service.*;

@Controller
public class ProductController {
	
	
    @Autowired
    ProductService productService;

    @GetMapping("/")
    public String homePage(Model model) {
        model.addAttribute("products", productService.getAllProducts());
        return "index";
    }

}
