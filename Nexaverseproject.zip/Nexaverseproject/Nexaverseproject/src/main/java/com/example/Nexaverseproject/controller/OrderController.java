package com.example.Nexaverseproject.controller;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.Nexaverseproject.service.OrderService;

@Controller
@RequestMapping("/order")
public class OrderController {

    @Autowired
    OrderService orderService;

    @PostMapping("/place")
    public String placeOrder(Principal principal, RedirectAttributes redirectAttributes) {
        if (principal == null) {
            return "redirect:/login";
        }

        try {
            orderService.placeOrder(principal.getName());
            return "redirect:/order/confirmation";
        } catch (RuntimeException ex) {
            // put error message into flash attributes so it shows on next page
            redirectAttributes.addFlashAttribute("errorMessage", ex.getMessage());
            return "redirect:/cart/view";
        }
    }

    @GetMapping("/confirmation")
    public String confirmationPage() {
        return "order-confirmation";
    }
}