package com.example.Nexaverseproject.controller;

import java.math.BigDecimal;
import java.security.Principal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.example.Nexaverseproject.model.CartItem;
import com.example.Nexaverseproject.service.CartService;

@Controller
@RequestMapping("/cart")
public class CartController {

    @Autowired
    private CartService cartService;

    // ADD ITEM TO CART
    @PostMapping("/add/{productId}")
    public String addToCart(@PathVariable Long productId, Principal principal) {
        if (principal == null) {
            return "redirect:/login";
        }
        cartService.addToCart(principal.getName(), productId);
        return "redirect:/cart/view";
    }

    // VIEW CART
    @GetMapping("/view")
    public String viewCart(Model model, Principal principal) {
        if (principal == null) {
            return "redirect:/login";
        }

        List<CartItem> items = cartService.getCartItems(principal.getName());

        BigDecimal total = items.stream()
                .map(i -> i.getProduct().getPrice()
                        .multiply(BigDecimal.valueOf(i.getQuantity())))
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        model.addAttribute("items", items);
        model.addAttribute("total", total);

        return "cart";
    }

    // UPDATE QUANTITY
    @PostMapping("/update")
    public String updateCart(@RequestParam("cartItemId") Long cartItemId,
                             @RequestParam("quantity") int quantity,
                             Principal principal) {
        if (principal == null) {
            return "redirect:/login";
        }
        cartService.updateCartItemQuantity(principal.getName(), cartItemId, quantity);
        return "redirect:/cart/view";
    }

    // REMOVE ITEM
    @PostMapping("/remove/{cartItemId}")
    public String removeFromCart(@PathVariable Long cartItemId, Principal principal) {
        if (principal == null) {
            return "redirect:/login";
        }
        cartService.removeFromCart(principal.getName(), cartItemId);
        return "redirect:/cart/view";
    }

    // CLEAR CART (optional)
    @PostMapping("/clear")
    public String clearCart(Principal principal) {
        if (principal == null) {
            return "redirect:/login";
        }
        cartService.clearCart(principal.getName());
        return "redirect:/cart/view";
    }
}
