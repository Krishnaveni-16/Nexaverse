package com.example.Nexaverseproject.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.*;
import com.example.Nexaverseproject.model.*;
public interface OrderRepository extends JpaRepository<Order, Long> {
    List<Order> findByUser(User user);
}
