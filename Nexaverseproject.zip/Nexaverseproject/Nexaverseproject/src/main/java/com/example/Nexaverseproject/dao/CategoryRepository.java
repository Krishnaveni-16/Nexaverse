package com.example.Nexaverseproject.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.Nexaverseproject.model.*;
public interface CategoryRepository extends JpaRepository<Category, Long> { }