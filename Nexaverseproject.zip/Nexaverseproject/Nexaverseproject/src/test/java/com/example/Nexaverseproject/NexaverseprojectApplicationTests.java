package com.example.Nexaverseproject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NexaverseprojectApplicationTests {

	@Test
	void contextLoads() {
	}

}
