package com.example.Nexaverseproject.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.*;
import com.example.Nexaverseproject.model.*;
public interface CartItemRepository extends JpaRepository<CartItem, Long> {
    List<CartItem> findByUser(User user);
}
